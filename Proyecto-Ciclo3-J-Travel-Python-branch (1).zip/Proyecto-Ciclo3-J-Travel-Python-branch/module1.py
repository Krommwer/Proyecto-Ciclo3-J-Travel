#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Estudiante
#
# Created:     24/03/2022
# Copyright:   (c) Estudiante 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def main():
    pass

if __name__ == '__main__':
    main()

